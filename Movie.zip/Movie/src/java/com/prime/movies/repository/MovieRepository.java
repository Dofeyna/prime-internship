package com.prime.movies.repository;

import com.prime.movies.domain.Movie;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class MovieRepository {
    
    @PersistenceContext
    private EntityManager em;
    
    public void persist(Movie movie) {
        em.persist(movie);
    }
    
    public List<Movie> getMovies() throws Exception{
        Query query = em.
        return query.getResultList();
    }
}
